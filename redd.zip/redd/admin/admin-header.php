<?php require_once(dirname(__FILE__).'/admin.php') ?>

<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Untitled</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        
    </head>
    <body>
        <div class="container">
        	<div class="row">
        		<div>
                    <ul class="nav navbar-nav">
                        <li class="nav-item"><a href="index.php" class="nav-link">Dashboard</a></li>
                        <li class="nav-item"><a href="inventory.php">Inventory</a></li>
                        <li class="nav-item"><a href="storage.php">Storage</a></li>
                        <li class="nav-item"><a href="calendar.php">Calendar</a></li>
                        <li class="nav-item"><a href="booking.php">Bookings</a></li>
                        <li class="nav-item"><a href="customer.php">Customer</a></li>
                        <li class="nav-item"><a href="page.php">Pages</a></li>
                        <li class="nav-item"><a href="setting.php">Setting</a></li>
                        <li>
                            <div>Username: <?php echo $_SESSION['username']; ?></div>
                            <form action="login.php" method="POST">
                                <div>
                                    <button type="submit" name="submit" value="logout" class="btn">Logout</button>
                                </div>
                            </form>
                        </li>
                    </ul>
        		</div>
        	</div>
        </div>