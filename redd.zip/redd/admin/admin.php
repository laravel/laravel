<?php 
	
	session_start();

	require_once(dirname(dirname(__FILE__)).'/include/general.php');

	if(!is_login())
		header('location:login.php'.'?redirect='.$_SERVER['PHP_SELF']);




 ?>