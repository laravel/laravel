<?php

require_once(dirname(dirname(dirname(__FILE__))).'/include/class-booking.php');
require_once(dirname(dirname(dirname(__FILE__))).'/include/class-customer.php');

$con = includedb();

##
#
# p1 -> id,cid,sid,bf,bt,cit,cif,cot,cof,status,fname,lname,msg,pcode,com
#
##

function searchBooking($p1 = array(),$p2 = array()){
	global $con;
	$condition = "";
	if(!empty($p1)){
		if(!empty($p2)){
			if(sizeof($p1)==sizeof($p2)){
				$i = 0;
				while ($i<sizeof($p1)) {
					switch ($p1[$i]) {
						case 'id':
							$condition .= "(b.id LIKE '%".$p2[$i]."%' OR '".$p2[$i]."'='') AND ";
							break;
						case 'cid':
							$condition .= "(c.id LIKE '%".$p2[$i]."%' OR '".$p2[$i]."'='') AND ";
							break;
						case 'sid' :
							$condition .= "(b.storage_id LIKE '%".$p2[$i]."%' OR '".$p2[$i]."'='') AND ";
							break;
						case 'bt' :
							$condition .= "(STR_TO_DATE('".$p2[$i]."', '%d/%m/%Y') >= "."b.datetime OR '".$p2[$i]."'='') AND ";
							break;
						case 'bf' :
							$condition .= "(STR_TO_DATE('".$p2[$i]."', '%d/%m/%Y') <= "."b.datetime OR '".$p2[$i]."'='') AND ";
							break;
						case 'cit' :
							$condition .= "(STR_TO_DATE('".$p2[$i]."', '%d/%m/%Y') >= "."b.start OR '".$p2[$i]."'='') AND ";
							break;
						case 'cif' :
							$condition .= "(STR_TO_DATE('".$p2[$i]."', '%d/%m/%Y') <= "."b.start OR '".$p2[$i]."'='') AND ";
							break;
						case 'cot' :
							$condition .= "(STR_TO_DATE('".$p2[$i]."', '%d/%m/%Y') >= "."b.expiry OR '".$p2[$i]."'='') AND ";
							break;
						case 'cof' :
							$condition .= "(STR_TO_DATE('".$p2[$i]."', '%d/%m/%Y') <= "."b.expiry OR '".$p2[$i]."'='') AND ";
							break;
						case 'status' :
							$condition .= "(b.staus =" .$p2[$i] ." OR " .$p2[$i] ."='' AND ";
							break;
						case 'fname':
							$condition .= "(c.firstname LIKE '%" .$p2[$i] ."%' OR '" .$p2[$i] ."'='' AND ";
							break;
						case 'lname' :
							$condition .= "(c.lastname LIKE '%" .$p2[$i] ."%' OR '" .$p2[$i] ."'='' AND ";
							break;
						case 'pcode' :

							break;
						case 'com' :
							$condition .= "(c.Company LIKE '%" .$p2[$i] ."%' OR '" .$p2[$i] ."'='' AND ";
							break;
					}
					$i++;
				}
				$condition .='1 ';
			}
			else{
				return false;
			}
		}
	}
	$sql = "SELECT b.id AS bid,b.* FROM bookings b INNER JOIN customers c ON b.customer_id = c.id INNER JOIN storages s ON b.storage_id = s.id WHERE ".$condition;
	$res = $con->query($sql);
	$ret = array();
	while($row = $res->fetch_assoc()){
		$temp = new Booking($row['bid'],$row['customer_id'],$row['storage_id'],$row['datetime'],$row['start'],$row['expiry'],$row['status']);
		array_push($ret, $temp);
	}
	return $ret;
}

##
# 
# p1 -> id,fname,lname,company,email,phone
#
##

function searchCustomer($p1='',$p2=''){
	global $con;
	$condition = '';
	if(!empty($p1)){
		if(!empty($p2)){
			if(sizeof($p1)==sizeof($p2)){
				$i = 0;
				while ($i<sizeof($p1)) {
					switch ($p1[$i]) {
						case 'id':
							$condition .= '';
							break;
						case 'fname':
							$condition .= '';
							break;
						case 'lname':
							$condition .= '';
							break;
						case 'company':
							$condition .= '';
							break;
						case 'email':
							$condition .= '';
							break;
						case 'phone':
							$condition .= '';
							break;
					}
					$i++;
				}
				$condition .='1 ';
			}
			else{
				return false;
			}
		}
		else{
			return false;
		}
	}
	$sql = "SELECT * FROM customers WHERE " .$condition;
	$res = $con->query($sql);
	$ret = array();
	while ($row = $res->fetch_assoc()) {
		array_push($ret, new Customer($row['id'],$row['firstname'],$row['lastname'],$row['Company'],$row['email'],$row['phone'],$row['status']));
	}

	return $ret;
}


function getbookingtoday(){
	global $con;
	$today = date('d/m/Y');
	$sql ="SELECT * FROM bookings WHERE (STR_TO_DATE('$today', '%d/%m/%Y') = `datetime`)";
	$res = $con->query($sql);
	$ret = array();
	while($row = $res->fetch_assoc()){
		$temp = new Booking($row['id'],$row['customer_id'],$row['storage_id'],$row['datetime'],$row['start'],$row['expiry'],$row['status']);
		array_push($ret, $temp);
	}
	return $ret;
}

function numCheckinToday(){
		global $con;
		$today = date('d/m/Y');
		$sql ="SELECT * FROM bookings WHERE (STR_TO_DATE('$today', '%d/%m/%Y') = start)";
		$res = $con->query($sql);
		$ret = array();
		while($row = $res->fetch_assoc()){
			$temp = new Booking($row['id'],$row['customer_id'],$row['storage_id'],$row['datetime'],$row['start'],$row['expiry'],$row['status']);
			array_push($ret, $temp);
		}
		return sizeof($ret);
	}



 ?>