<?php require_once(dirname(__FILE__).'/admin-header.php'); ?>
<?php require_once(dirname(__FILE__).'/include/search-functions.php') ?>

<div class="container">
	<div class="row">
		<div>
			<p>New Booking: ?</p>
			<p>Check-in Today: <?php echo sizeof(searchbooking(array('cit','cif'),array(date('d/m/Y'),date('d/m/Y')))); ?></p>
			<p>Check-out Today: <?php echo numcheckintoday(); ?></p>
			<p>Upcoming: </p>
			<p>Occupancy: </p>
			<p>Unit Available:</p>
		</div>
	</div>
	<div class="row">
		<?php //var_dump(searchbooking(array('dt','id'),array('28/09/2017','322'))) ;?>
		<?php var_dump(searchbooking(array('id','cid'),array('663','784'))) ;?>
	</div>
</div>

        



<?php require_once(dirname(__FILE__).'/admin-footer.php'); ?>