<?php session_start(); ?>
<!doctype html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Login</title>
    </head>
    <body>
        <?php if(isset($_SESSION['login'])){exit('isset login');} ?>
        <form action="login.php" method="post">
        	<input type="text" name="username">
        	<input type="password" name="pwd">
        	<button type="submit" name="submit" value="login">login</button>
        	Username : admin
        	Pass : pass
        </form>
        <!-- <form action="login.php" method="post">
        	<button type="submit" name="submit" value="logout">logout</button>
        </form> -->
        <?php if(isset($_POST['submit'])){
        	if($_POST['submit']=='login'){
        		$_SESSION['login'] = 1;
                $_SESSION['username'] = 'admin';
        		if(!isset($_GET['redirect']))
        			header('Location:index.php');
        		else
        			header('Location:'.$_GET['redirect']);
        		exit('header');
        	}
        	elseif($_POST['submit']=='logout'){
        		session_destroy();
        		if(!isset($_GET['redirect']))
        			header('Location:login.php');
        		exit('header');
        	}
        	
        	} ?>

    </body>
</html>