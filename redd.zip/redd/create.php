<form action"create.php" method="get">
	<button type="submit" name="submit">create</button>
</form>

<?php 

$servername = "localhost";
$username = "username";
$password = "password";

// Create connection
$conn = new mysqli('localhost', 'root', '','redd_laravel');

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";
	$j = 625;
	if(isset($_GET['submit'])){
		for($i=1;$i<=76;$i++){
			$name = 'G'.$i;
			// $sql = "UPDATE units SET name='$name' where type_id=27 AND id=$j";
			$sql = "INSERT units (name,type_id,floor,status) VALUES('$name',31,1,1) ";
			$res = $conn->query($sql);
			// $j++;
		}
	}

 ?>