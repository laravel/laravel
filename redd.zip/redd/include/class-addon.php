<?php 

	/**
	* 
	*/
	class Addon
	{
		
		public $id;
		public $name;
		public $cost;
		public $cost_unit;
		public $descp;
		public $status;
		public $note;

		function __construct1($id,$name,$cost,$cost_unit,$descp)
		{
			$this->id = $id;
			$this->name = $name;
			$this->cost = $cost;
			$this->cost_unit = $cost_unit;
			$this->descp = $descp;
		}

		function __construct($id,$name,$cost,$cost_unit,$descp,$status){
			$this->id = $id;
			$this->name = $name;
			$this->cost = $cost;
			$this->cost_unit = $cost_unit;
			$this->descp = $descp;
			$this->status = $status;
		}

		public static function getAllAddon(){
			require_once('../include/class-storage.php');
			include('../include/db_con.php');

			$sql="SELECT * FROM addons WHERE status!=0";
			$res = $conn->query($sql);
			$ret = array();
			if($res->num_rows>0){
				while ($row = $res->fetch_assoc()) {
					$temp = new Addon($row['id'],$row['name'],$row['cost'],$row['cost_unit'],$row['descp'],$row['status']);
					array_push($ret, $temp);
				}
			}
			else{
				//0 row
			}

			return $ret;
		}

		public static function getAddonInfo($id){

		}

		public function toStringCostUnit(){
			switch ($this->cost_unit) {
				case 1:
					return 'Per day';
					break;
				case 2:
					return 'Per booking';
					break;
			}
		}
	}

 ?>