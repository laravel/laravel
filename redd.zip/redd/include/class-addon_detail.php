<?php 

	class Addon_detail{
		public $id;
		public $addon_id;

		function __construct($id,$addon_id){
			
			$this->id = $id;
			$this->addon_id = $addon_id;
		}

		public function __get($property){

        	if(property_exists($this,$property)){
            	return $this->property;
        	}
    	}

    	public function __set($property, $value) {
    		
    		if (property_exists($this, $property)) {
      			$this->property = $value;
    		}

    		return $this;
  		}
	}


 ?>