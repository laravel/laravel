<?php 
	/**
	* 
	*/
	class Booking{
		
		public $id;
		public $customer_id;
		public $storage_id;
		public $datetime;
		public $start;
		public $expiry;
		public $status;
		public $note;

		function __construct($id,$customer_id,$storage_id,$datetime,$start,$expiry,$status){
			
			$this->id = $id;
			$this->customer_id = $customer_id;
			$this->storage_id = $storage_id;
			$this->datetime = $datetime;
			$this->start = $start;
			$this->expiry = $expiry;
			$this->status = $status;
		}

		public function __get($property){

        	if(property_exists($this,$property)){
            	return $this->property;
        	}
    	}

    	public function __set($property, $value) {
    		
    		if (property_exists($this, $property)) {
      			$this->property = $value;
    		}

    		return $this;
  		}

  		public static function getAllBooking(){
  			$require_once('db_con.php');
  			$sql = "SELECT * FROM bookings";
  			$res = $conn->query($sql);
  			$ret = array();
  			while($row = $res->fetch_assoc()){
  				$temp = new Booking($row['id'],$row['customer_id'],$row['storage_id'],$row['datetime'],$row['start'],$row['expiry'],$row['status']);
  				array_push($ret, $temp);
  			}

  			return $ret;
  		}

  		public function getstatus(){
  			switch ($this->status) {
  				case 1:
  					return 'Pending';
  					break;
  				case 2:
  					return 'Reserved';
  					break;
  				case 3:
  					return 'Paid';
  					break;
  				case 4:
  					return 'Cancelled';
  					break;
  				default:
  					# code...
  					break;
  			}
  		}
	}


 ?>