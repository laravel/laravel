<?php 
	/**
	* 
	*/
	class Customer{

		public $id;
		public $company;
		public $fname;
		public $lname;
		public $email;
		public $phone;
		public $status;
		public $username;
		public $pwd;

		function __construct($id,$fname,$lname,$company,$email,$phone,$status=1){
			$this->fname = $fname;
			$this->lname = $lname;
			$this->email = $email;
			$this->id = $id;
			$this->company = $company;
			$this->phone = $phone;
			$this->status = $status;
		}

		function __construct1($username,$pwd){
			$this->username = $username;
			$this->pwd = $pwd;
		}

		function __construct2($firstname,$username,$email,$username,$pwd){
			$this->firstname = $firstname;
			$this->lastname = $lastname;
			$this->email = $email;
			$this->username = $username;
			$this->pwd = $pwd;
		}

		public function __get($property){

        	if(property_exists($this,$property)){
            	return $this->property;
        	}
    	}

    	public function __set($property, $value) {
    		
    		if (property_exists($this, $property)) {
      			$this->property = $value;
    		}

    		return $this;
  		}



		
		
	}

 ?>	