<?php 
	/**
	* 
	*/
	class History {

		private $record_time;
		private $storage_id;
		private $customer_id;
		
		function __construct($record_time,$storage_id,$customer_id;){
			$this->record_time = $record_time;
			$this->storage_id = $storage_id;
			$this->customer_id = $customer_id;
		}

		public function __get($property){

        	if(property_exists($this,$property)){
            	return $this->$property;
        	}
    	}

    	public function __set($property, $value) {
    		
    		if (property_exists($this, $property)) {
      			$this->$property = $value;
    		}

    		return $this;
  		}

	}

 ?>