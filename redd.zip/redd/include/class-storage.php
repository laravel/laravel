<?php 
	/**
	* 
	*/
	class Storage{

		public $id;
		public $name;
    public $typeid;
		public $floor;
		public $descp;
		public $status;

		function __construct($id,$name,$typeid,$floor,$descp,$status){
			$this->id = $id;
			$this->name = $name;
      $this->typeid = $typeid;
			$this->floor = $floor;
			$this->descp = $descp;
      $this->status = $status;
		}

		function __construct1($size){
			$this->size = $size;
		}

		public function __get($property){

        	if(property_exists($this,$property)){
            	return $this->$property;
        	}
    	}

    	public function __set($property, $value) {
    		
    		if (property_exists($this, $property)) {
      			$this->$property = $value;
    		}

    		return $this;
  		}

  		public static function getAllStorage(){
  			require_once('db_con.php');
  			$sql = "SELECT * FROM storages WHERE status!=0";
  			$res = $conn->query($sql);
  			$ret = array();
  			while($row = $res->fetch_assoc()){
  				$temp = new Storage($row['id'],$row['name'],$row['storage_type_id'],$row['floor'],$row['descp'],$row['status']);
  				array_push($ret, $temp);
  			}

  			return $ret;
  		}

  		public static function getunitinfo($id){
  			require('db_con.php');
  			$sql = "SELECT * FROM storages WHERE id='$id'";
  			$res = $conn->query($sql);
  			while ($row = $res->fetch_assoc()) {
  				return new Storage($row['id'],$row['name'],$row['storage_type_id'],$row['floor'],$row['descp'],$row['status']);
  			}
  		}

      public function getTypeSelect(){
        include('db_con.php');
        $sql = "SELECT id,name FROM storage_types WHERE status!=0";
        $res = $conn->query($sql);
        $ret = '';
        while($row = $res->fetch_assoc()){
          $ret .= '<option ';
          $ret .= 'value="' .$row['id'] .'"';
          if($this->typeid==$row['id']){
            $ret .= ' selected ';
          }
          $ret .= '>';
          $ret .= $row['name'];
          $ret .= '</option>';
        }

        echo $ret;
      }

      public static function getTypeSelect2(){
        include('db_con.php');
        $sql = "SELECT id,name FROM storage_types WHERE status!=0";
        $res = $conn->query($sql);
        $ret = '<option value="-1">All</option>';
        while($row = $res->fetch_assoc()){
          $ret .= '<option ';
          $ret .= 'value="' .$row['id'] .'"';
          $ret .= '>';
          $ret .= $row['name'];
          $ret .= '</option>';
        }

        echo $ret;
      }

      public function getStatusSelect(){
        switch ($this->status) {
          case '1':
            echo '<option value="1" selected>Active</option>';
            echo '<option value="2">Not Active</option>';
            break;
          
          case '2':
            echo '<option value="1">Active</option>';
            echo '<option value="2"  selected>Not Active</option>';
            break;
          default:
            echo '<option value="1">Active</option>';
            echo '<option value="2">Not Active</option>';
        }
      }





	}

 ?>