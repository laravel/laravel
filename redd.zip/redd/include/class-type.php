<?php 

	/**
	* 
	*/ 
	class Type
	{
		public $id;
		public $name;
		public $size;
		public $cost;
		public $cost_unit = 0;
		public $descp;
		public $img_url = 'type-default.jpg'; // img test
		public $status;

		function __construct($id,$name,$size,$cost,$cost_unit,$descp,$img_url,$status){
			$this->id = $id;
			$this->name = $name;
			$this->size = $size;
			$this->cost = $cost;
			$this->cost_unit = $cost_unit;
			$this->descp = $descp;
			// $this->img_url = $img_url;  //img test
			$this->status = $status;
		}

		function __construct1($id,$name,$size,$cost,$cost_unit,$descp){
			$this->id = $id;
			$this->name = $name;
			$this->size = $size;
			$this->cost = $cost;
			$this->cost_unit = $cost_unit;
			$this->descp = $descp;
		}

		function __construct2($id,$name,$size,$cost,$cost_unit,$descp,$img_url){
			$this->id = $id;
			$this->name = $name;
			$this->size = $size;
			$this->cost = $cost;
			$this->cost_unit = $cost_unit;
			$this->descp = $descp;
			// $this->img_url = $img_url;  //img test
		}

		function idandname($id,$name){
			$this->id=$id;
			$this->name = $name;
		}

		public function __get($property){

        	if(property_exists($this,$property)){
            	return $this->property;
        	}
    	}

    	public function __set($property, $value) {
    		
    		if (property_exists($this, $property)) {
      			$this->property = $value;
    		}

    		return $this;
  		}

  		public static function getAlltype(){
  			require_once('db_con.php');
  			$sql = "SELECT * FROM storage_types";
  		}

  		public function getStatus(){
  			switch ($this->status) {
  				case 0:
  					return 'Deleted';
  					break;
  				
  				case 1:
  					return 'Active';
  					break;
  				case 2:
  					return 'Not Active';
  					break;
  			}
  		}

  		
	}


 ?>