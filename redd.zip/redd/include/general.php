<?php 

function login_url($redirect='',$force=false){
	$login_url = 'login.php';
 
    if ( !empty($redirect) )
        $login_url;
 
    if ( $force_reauth )
        $login_url;

    return $login_url;
}

function admin_login_url($redirect=''){
	$ret = $_SERVER['SERVER_NAME'].'/redd/admin/login.php';

	return $ret;
}

function is_login(){
	if(isset($_SESSION['login']))
		return true;
	else
		return false;
}

function is_admin(){
	if (!defined('ADMIN'))
		return false;
	else
		if(ADMIN===true)
			return true;
		else
			return false;
}

function includeDB(){
	$_SERVER["DOCUMENT_ROOT"];
	$_SERVER['SERVER_NAME'];
	require_once($_SERVER["DOCUMENT_ROOT"] .'/redd/include/db_con.php');
	return $conn;
}







 ?>